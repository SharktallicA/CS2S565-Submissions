
#pragma once

namespace CoreStructures {

	struct CGTextureCoord {

		float			s, t, q, w;
	};
}
