
#pragma once

#include "gu_math.h"

namespace CoreStructures {

	struct CGColorRGB {

		gu_byte			r, g, b;
	};
}

