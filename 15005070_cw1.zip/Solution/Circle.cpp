#include "stdafx.h"
#include "Circle.h"

using namespace std;
using namespace CoreStructures;

Circle::Circle(GLuint newTexture)
{
	//purpose: constructor of textured circular ship component
	//parametres: (newTexture) reference to texture file

	textureFile = newTexture;
	construct();
}
Circle::Circle(RGBAColour* newColour)
{
	//purpose: constructor of coloured circular ship component
	//parametres: (newColour) reference to colour

	colour = newColour;
	constructNoTexture();
}
void Circle::construct(void)
{
	//purpose: sets up circular ship component
	//pre-condition: program is in the constructor of the object

	GUVector2* vctXYCoords = (GUVector2*)malloc(intNoOfPoints * sizeof(GUVector2)); //vectorise X-axis and Y-axis points
	GUVector2* vctTextureCoords = (GUVector2*)malloc(intNoOfPoints * sizeof(GUVector2)); //vectorise texture mapping points

	if (vctXYCoords && vctTextureCoords)
	{
		//store point at origin (centre of circle / triangle fan used to render the circle)
		vctXYCoords[0].x = 0.0f;
		vctXYCoords[0].y = 0.0f;

		vctTextureCoords[0].x = 0.5f;
		vctTextureCoords[0].y = 0.5f;

		//setup points around the circumference of the circle
		float theta = 0.0f;
		float theta_delta = (gu_pi * 2.0f) / float(intNoOfPointsOnCircle);

		for (int i = 1; i < intNoOfPoints; ++i, theta += theta_delta)
		{
			float x = cosf(theta);
			float y = sinf(theta);

			//setup vertex coordinate
			vctXYCoords[i].x = x;
			vctXYCoords[i].y = y;

			//setup corresponding texture coordinate
			vctTextureCoords[i].x = (x * 0.5f) + 0.5f;
			vctTextureCoords[i].y = 1.0f - ((y * 0.5f) + 0.5f);
		}

		//setup VAO
		glGenVertexArrays(1, &objVAO);
		glBindVertexArray(objVAO);

		//vertices to VBO
		glGenBuffers(1, &vertexVBO);
		glBindBuffer(GL_ARRAY_BUFFER, vertexVBO);
		glBufferData(GL_ARRAY_BUFFER, intNoOfPoints * sizeof(GUVector2), vctXYCoords, GL_STATIC_DRAW);
		glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
		glEnableVertexAttribArray(0);

		//texture co-ordinates to VBO
		glGenBuffers(1, &textureVBO);
		glBindBuffer(GL_ARRAY_BUFFER, textureVBO);
		glBufferData(GL_ARRAY_BUFFER, intNoOfPoints * sizeof(GUVector2), vctTextureCoords, GL_STATIC_DRAW);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
		glEnableVertexAttribArray(2);

		//unbind VAO
		glBindVertexArray(0);

		//dispose of buffers
		free(vctXYCoords);
		free(vctTextureCoords);
	}
}
void Circle::constructNoTexture(void)
{
	//purpose: sets up circular ship component
	//pre-condition: program is in the constructor of the object

	GUVector2* vctXYCoords = (GUVector2*)malloc(intNoOfPoints * sizeof(GUVector2));
	
	/*vector<GLubyte> colours;
	for (int i = 0; i < intNoOfPointsOnCircle; i++)
	{
		colours.push_back(colour->R);
		colours.push_back(colour->G);
		colours.push_back(colour->B);
		colours.push_back(colour->A);
	}*/

	if (vctXYCoords)
	{
		//store point at origin (centre of circle / triangle fan used to render the circle)
		vctXYCoords[0].x = 0.0f;
		vctXYCoords[0].y = 0.0f;

		//setup points around the circumference of the circle
		float theta = 0.0f;
		float theta_delta = (gu_pi * 2.0f) / float(intNoOfPointsOnCircle);

		for (int i = 1; i < intNoOfPoints; ++i, theta += theta_delta)
		{
			float x = cosf(theta);
			float y = sinf(theta);

			//setup vertex coordinate
			vctXYCoords[i].x = x;
			vctXYCoords[i].y = y;
		}

		//setup VAO
		glGenVertexArrays(1, &objVAO);
		glBindVertexArray(objVAO);

		//vertices to VBO
		glGenBuffers(1, &vertexVBO);
		glBindBuffer(GL_ARRAY_BUFFER, vertexVBO);
		glBufferData(GL_ARRAY_BUFFER, intNoOfPoints * sizeof(GUVector2), vctXYCoords, GL_STATIC_DRAW);
		glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
		glEnableVertexAttribArray(0);

		//colours to VBO
		/*glGenBuffers(1, &colourVBO);
		glBindBuffer(GL_ARRAY_BUFFER, colourVBO);
		glBufferData(GL_ARRAY_BUFFER, colours.size() * sizeof(GLubyte), &colours[0], GL_STATIC_DRAW);
		glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
		glEnableVertexAttribArray(1);*/

		//unbind VAO
		glBindVertexArray(0);

		//dispose of buffers
		free(vctXYCoords);
	}
}
void Circle::render(void)
{
	//purpose: renders circular ship component
	//pre-condition: called in parent (Daedalus) render() method

	if (colour == nullptr) glBindTexture(GL_TEXTURE_2D, textureFile);
	glBindVertexArray(objVAO);
	glDrawArrays(GL_TRIANGLE_FAN, 0, intNoOfPoints);
}