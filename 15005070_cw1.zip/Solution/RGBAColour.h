#pragma once

#include <glew\glew.h>

using namespace std;

struct RGBAColour
{
	//purpose: custom struct for passing RGBA values without the need for four float values

	GLubyte R, G, B, A;

	RGBAColour() {};
	RGBAColour(GLubyte nR, GLubyte nG, GLubyte nB, GLubyte nA)
	{
		R = nR;
		G = nG;
		B = nB;
		A = nA;
	}

	void operator=(const RGBAColour other)
	{
		R = other.R;
		G = other.G;
		B = other.B;
		A = other.A;
	}
};