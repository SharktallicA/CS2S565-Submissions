#include "stdafx.h"
#include "Background.h"

Background::Background()
{
}