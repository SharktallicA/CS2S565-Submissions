#include "stdafx.h"
#include "Square.h"

using namespace std;
using namespace CoreStructures;

Square::Square(GLuint newTexture, vector<GLfloat> vertices, vector<float> coords)
{
	//purpose: default constructor of square ship component

	textureFile = newTexture;
	construct(vertices, coords);
}
void Square::construct(vector<GLfloat> vertices, vector<float> coords)
{
	//purpose: sets up square ship component
	//pre-condition: program is in the constructor of the object

	//square indices
	static GLubyte indices[] = {
		0, 1, 2, 3
	};

	//setup VAO
	glGenVertexArrays(1, &objVAO);
	glBindVertexArray(objVAO);

	//vertices to VBO
	glGenBuffers(1, &vertexVBO);
	glBindBuffer(GL_ARRAY_BUFFER, vertexVBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), &vertices[0], GL_STATIC_DRAW);
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
	glEnableVertexAttribArray(0);

	//texture co-ordinates to VBO
	glGenBuffers(1, &textureVBO);
	glBindBuffer(GL_ARRAY_BUFFER, textureVBO);
	glBufferData(GL_ARRAY_BUFFER, coords.size() * sizeof(float), &coords[0], GL_STATIC_DRAW);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
	glEnableVertexAttribArray(2);

	//indices to VBO
	glGenBuffers(1, &indexVBO);
	glBindBuffer(GL_ARRAY_BUFFER, indexVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	//unbind VAO
	glBindVertexArray(0);
}
void Square::render(void)
{
	//purpose: renders square ship component
	//pre-condition: called in parent (Daedalus) render() method

	glBindTexture(GL_TEXTURE_2D, textureFile);
	glBindVertexArray(objVAO);
	glDrawArrays(GL_POLYGON, 0, 4);
}