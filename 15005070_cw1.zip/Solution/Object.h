#pragma once

#include <glew\glew.h>
#include <freeglut\freeglut.h>
#include <CoreStructures\CoreStructures.h>
#include "texture_loader.h"
#include "shader_setup.h"
#include "RGBAColour.h"
#include <vector>

using namespace std;

class Object
{
	//purpose: Object bass class for common functionality

protected:
	GLuint objVAO, vertexVBO, textureVBO, colourVBO, indexVBO, textureFile;
	RGBAColour* colour = nullptr; //holds a colour if needed

public:
	Object() {};
	~Object() { delete colour; };

	void construct(void) {};
	void render(void) {};
};