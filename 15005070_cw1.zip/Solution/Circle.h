#pragma once

#include "Object.h"

class Circle : protected Object
{
	//purpose: circular object (ie. ship saucer and bussard)

private:
	const int intNoOfPointsOnCircle = 32; //number of points of circle
	const int intNoOfPoints = intNoOfPointsOnCircle + 2; //number of points taking to account circle center and first point at the end of the triangle fan

public:
	Circle(GLuint);
	Circle(RGBAColour*);

	void construct(void);
	void constructNoTexture(void);
	void render(void);
};