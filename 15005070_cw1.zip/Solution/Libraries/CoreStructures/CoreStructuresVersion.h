
#pragma once

#include "GUVersion.h"

namespace CoreStructures {

	// public function to report the current version info of the CoreStructures (static) library
	GUVersion getCoreStructuresVersion();

}