#pragma once

#include "Object.h"

class Square : protected Object
{
	//purpose: square ship component (ie. hull and nacelle)

public:
	Square(GLuint, vector<GLfloat>, vector<float>);

	void construct(vector<GLfloat>, vector<float>);
	void render(void);
};