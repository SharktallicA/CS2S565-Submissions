#include "stdafx.h"
#include "Pulsar.h"

using namespace std;
using namespace CoreStructures;

Pulsar::Pulsar()
{
	//purpose: constructs the pulsar object
	//pre-condition: object is created in the init() method in Source.cpp


	//initialise circular components
	ball1 = new Circle(new RGBAColour(0, 200, 250, 255));
	ball2 = new Circle(new RGBAColour(0, 200, 250, 255));

	//load in shaders for pulsars
	pulsarShaderBlue = setupShaders(string("Shaders\\pulsar_vertex_shader.txt"), string("Shaders\\blue_fragment_shader.txt"));
	pulsarShaderRed = setupShaders(string("Shaders\\pulsar_vertex_shader.txt"), string("Shaders\\red_fragment_shader.txt"));

	//setup uniform locations
	locB = glGetUniformLocation(pulsarShaderBlue, "B");
}
void Pulsar::render(float fltX, float fltY, float fltScale, float fltRotation)
{
	//purpose: renders all components of the ship and transforms them relative to the hull component of the ship
	//pre-condition: method is called in display() method in Source.cpp

	//setup blending for alpha transparency
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE);

	//draw first ball
	glUseProgram(pulsarShaderRed); //use red shader
	GUMatrix4 defaultTransform = GUMatrix4::translationMatrix(fltX, fltY, 0.0f) * GUMatrix4::rotationMatrix(fltRotation * gu_radian, fltRotation * gu_radian, fltRotation * gu_radian) * GUMatrix4::scaleMatrix(fltScale * 0.115f, fltScale * 0.2f, fltScale); //create matrices based on input parametres
	glUniformMatrix4fv(locB, 1, GL_FALSE, (GLfloat*)&defaultTransform); //parse transformation to shader
	ball1->render();

	//draw second ball
	glUseProgram(pulsarShaderBlue); //use blue shader
	GUMatrix4 firstToSecond = GUMatrix4::translationMatrix(-0.0f, 0.0f, 0.0f)* GUMatrix4::rotationMatrix(fltRotation * gu_radian, fltRotation * gu_radian, 0.0f);
	GUMatrix4 secondTransform = defaultTransform * firstToSecond;
	glUniformMatrix4fv(locB, 1, GL_FALSE, (GLfloat*)&secondTransform);
	ball2->render();

	//disable states and shader programs used
	glDisable(GL_BLEND);
	glUseProgram(0);
}