#include "stdafx.h"
#include "Daedalus.h"

using namespace std;
using namespace CoreStructures;

Daedalus::Daedalus()
{
	//purpose: constructs the USS Daedalus ship object
	//pre-condition: object is created in the init() method in Source.cpp

	//initialise hull component
	vector<GLfloat> hullVertices = {
		-0.2f, 0.4f,
		-0.2f, 0.1f,
		0.2f, 0.1f,
		0.2f, 0.4f
	};
	vector<float> hullCoords = {
		0, 0,
		0, 1,
		1, 1,
		1, 0
	};
	hull = new Square(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Daedalus\\imgHull.png"))), hullVertices, hullCoords);

	//initialise neck component
	vector<GLfloat> neckVertices = {
		-0.6f, 0.4f,
		-0.2f, 0.4f,
		-0.2f, 0.3f,
		-0.6f, 0.3f
	};
	vector<float> neckCoords = {
		0, 0,
		1, 0,
		1, 1,
		0, 1
	};
	neck = new Square(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Daedalus\\imgNeck.png"))), neckVertices, neckCoords);

	//initialise saucer component
	saucer = new Circle(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Daedalus\\imgSaucer.png"))));

	//initialise bussard component
	bussard = new Circle(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Daedalus\\imgBussard.png"))));

	//initialise nacelle component
	vector<GLfloat> nacelleVertices = {
		0.25f, 0.45f,
		0.25f, 0.57f,
		-0.35f, 0.57f,
		-0.35f, 0.45f
	};
	vector<float> nacelleCoords = {
		1, 1,
		1, 0,
		0, 0,
		0, 1
	};
	nacelle = new Square(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Daedalus\\imgNacelle.png"))), nacelleVertices, nacelleCoords);

	//initialise pylon componenet
	vector<GLfloat> pylonVertices = {
		-0.3f, 0.45f,
		-0.3f, 0.375f,
		-0.25f, 0.375f,
		-0.25f, 0.45f
	};
	vector<float> pylonCoords = {
		1, 1,
		1, 0,
		0, 0,
		0, 1
	};
	pylon = new Square(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Daedalus\\imgPylon.png"))), pylonVertices, pylonCoords);

	//load in shader for textures
	shipShader = setupShaders(string("Shaders\\texture_vertex_shader.txt"), string("Shaders\\texture_fragment_shader.txt"));

	//setup uniform locations
	locT = glGetUniformLocation(shipShader, "T");
}
void Daedalus::render(float fltX, float fltY, float fltScale, float fltOrientation)
{
	//purpose: renders all components of the ship and transforms them relative to the hull component of the ship
	//pre-condition: method is called in display() method in Source.cpp

	glUseProgram(shipShader); //use ship's shader program

	//draw hull
	GUMatrix4 defaultTransform = GUMatrix4::translationMatrix(fltX, fltY, 0.0f) * GUMatrix4::rotationMatrix(0.0f, 0.0f, fltOrientation * gu_radian) * GUMatrix4::scaleMatrix(fltScale, fltScale, fltScale); //create matrices based on input parametres
	glUniformMatrix4fv(locT, 1, GL_FALSE, (GLfloat*)&defaultTransform); //parse transformation to shader
	hull->render();

	//draw neck
	GUMatrix4 neckToHull = GUMatrix4::translationMatrix(-0.05f, 0.0f, 0.0f) * GUMatrix4::scaleMatrix(0.75f, 1.0f, 1.0f);
	GUMatrix4 neckTransform = defaultTransform * neckToHull;
	glUniformMatrix4fv(locT, 1, GL_FALSE, (GLfloat*)&neckTransform);
	neck->render();

	//draw saucer
	GUMatrix4 saucerToHull = GUMatrix4::translationMatrix(-0.6f, 0.45f, 0.0f) * GUMatrix4::scaleMatrix(0.15f, 0.27f, 1.0f);
	GUMatrix4 saucerTransform = defaultTransform * saucerToHull;
	glUniformMatrix4fv(locT, 1, GL_FALSE, (GLfloat*)&saucerTransform);
	saucer->render();

	//draw bussard
	GUMatrix4 bussardToHull = GUMatrix4::translationMatrix(-0.35f, 0.511f, 0.0f) * GUMatrix4::scaleMatrix(0.035f, 0.06f, 1.0f);
	GUMatrix4 bussardTransform = defaultTransform * bussardToHull;
	glUniformMatrix4fv(locT, 1, GL_FALSE, (GLfloat*)&bussardTransform);
	bussard->render();

	//draw nacelle
	GUMatrix4 nacelleToHull = GUMatrix4::translationMatrix(0.0f, 0.0f, 0.0f) * GUMatrix4::scaleMatrix(1.0f, 1.0f, 1.0f);
	GUMatrix4 nacelleTransform = defaultTransform * nacelleToHull;
	glUniformMatrix4fv(locT, 1, GL_FALSE, (GLfloat*)&nacelleTransform);
	nacelle->render();

	//draw pylon
	GUMatrix4 pylonToHull = GUMatrix4::translationMatrix(0.03f, 0.0f, 0.0f) * GUMatrix4::scaleMatrix(1.0f, 1.0f, 1.0f);
	GUMatrix4 pylonTransform = defaultTransform * pylonToHull;
	glUniformMatrix4fv(locT, 1, GL_FALSE, (GLfloat*)&pylonTransform);
	pylon->render();

	glUseProgram(0);
}