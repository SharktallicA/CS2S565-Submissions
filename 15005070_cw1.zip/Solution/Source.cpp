// "A typical Federation day" - Khalid Ali (15005070)

#include "stdafx.h"
#include <glew\glew.h>
#include <freeglut\freeglut.h>
#include <CoreStructures\CoreStructures.h>
#include "texture_loader.h"
#include "shader_setup.h"
#include "Pulsar.h"
#include "Daedalus.h"
#include "Square.h"
#include "RGBAColour.h"
#include <vector>

using namespace std;
using namespace CoreStructures;

#pragma region Mouse globals
int intMouseX, intMouseY; //stores mouse location
bool boolMouseDown = false; //flags if mouse is being pressed
#pragma endregion

#pragma region Globals
GLuint locT, locC, textureShader, colourShader;
const float fltSTEP = 0.015f; //constant amount that ship moves via keys
int intVibration = 1;
#pragma endregion

#pragma region Space variables
Square* background = nullptr;
vector<GLfloat> backgroundVertices = {
	-1.0f, 1.0f,
	1.0f, 1.0f,
	1.0f, -1.0f,
	-1.0f, -1.0f
};
vector<float> backgroundCoords = {
	0, 0,
	1, 0,
	1, 1,
	0, 1
};
Circle* planet = nullptr;
Pulsar* pulsar = nullptr;
float fltPulsarX = -0.7f;
float fltPulsarY = 0.5f;
float fltPulseRotation = 0.0f;
Circle* asteroid = nullptr;
float fltAsteroidX = -0.6f;
float fltAsteroidY = 0.5f;
float fltAsteroidRotation = 0.0f;
#pragma endregion

#pragma region Starfleet & Daedalus variables
vector<Daedalus*> starfleet; //holds multiple Daedalus-class ship objects
float fltShipX = 0.5f; //relative X-axis position
float fltShipY = -0.75f; //relative Y-axis position
float fltShipPitch = 0.0f; //relative pitch (not currently used)
int intFleetSize = 3; //global size of starfleet vector
#pragma endregion

#pragma region OpenGL function prototypes
void init(int argc, char* argv[]);
void update(void);
void display(void);
void mouseButtonDown(int button_id, int state, int x, int y);
void mouseMove(int x, int y);
void keyDown(unsigned char key, int x, int y);
#pragma endregion

#pragma region Transformers
void buildBackground()
{
	//purpose: applies needed transformation for background and then displays the result
	//pre-condition: called in OGL display() method

	GUMatrix4 transformer = GUMatrix4::scaleMatrix(1.1f, 1.0f, 1.0f);
	glUniformMatrix4fv(locT, 1, GL_FALSE, (GLfloat*)&transformer);
	background->render();
}
void buildPlanet()
{
	//purpose: applies needed transformation for planet and then displays the result
	//pre-condition: called in OGL display() method

	GUMatrix4 transformer = GUMatrix4::scaleMatrix(0.75f, 0.75f, 0.75f) * GUMatrix4::rotationMatrix(0.0f, 0.0f, 5.0f ) * GUMatrix4::translationMatrix(2.0f, 0.25f, 0.0f);
	glUniformMatrix4fv(locC, 1, GL_FALSE, (GLfloat*)&transformer);
	planet->render();
}
void buildAsteroid()
{
	//purpose: applies needed transformation for asteroid and then displays the result
	//pre-condition: called in OGL display() method

	GUMatrix4 transformer = GUMatrix4::scaleMatrix(0.15f, 0.25f, 0.25f)* GUMatrix4::rotationMatrix(0.0f, 0.0f, fltAsteroidRotation * gu_radian) * GUMatrix4::translationMatrix(fltAsteroidX, fltAsteroidY, 0.0f);
	glUniformMatrix4fv(locC, 1, GL_FALSE, (GLfloat*)&transformer);
	asteroid->render();
}
#pragma endregion

int _tmain(int argc, char* argv[])
{
	init(argc, argv);
	glutMainLoop();
	shutdownCOM(); //shut down COM
	return 0;
}
void init(int argc, char* argv[])
{
	initCOM(); //initialise COM for Windows Imaging Component

	glutInit(&argc, argv); //initiase FreeGLUT

	//set OGL window properties
	glutInitContextVersion(3, 3);
	glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DEPTH | GLUT_DOUBLE);
	glutInitWindowSize(1366, 768);
	glutInitWindowPosition(64, 64);
	glutCreateWindow("Khalid Ali (15005070)");

	//register callback functions
	glutIdleFunc(update);
	glutDisplayFunc(display);
	glutMouseFunc(mouseButtonDown); 
	glutMotionFunc(mouseMove); 
	glutKeyboardFunc(keyDown);

	GLenum err = glewInit(); //initialise GLEW library

	//ensure GLEW is initialised successfully
	if (err == GLEW_OK)
		cout << "GLEW initialised okay\n";
	else
	{
		cout << "GLEW could not be initialised\n";
		throw;
	}

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f); //clears screen to default colour

	//create shader instances
	textureShader = setupShaders(string("Shaders\\texture_vertex_shader.txt"), string("Shaders\\texture_fragment_shader.txt"));
	locT = glGetUniformLocation(textureShader, "T");

	//create scene objects
	background = new Square(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Space\\imgStars.png"))), backgroundVertices, backgroundCoords);
	planet = new Circle(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Space\\imgJupiter.png"))));
	pulsar = new Pulsar();
	asteroid = new Circle(GLuint(wicLoadTexture(wstring(L"Resources\\Textures\\Space\\imgAsteroid.png"))));

	//create fleet of Daedalus-class ships
	for (int i = 0; i < intFleetSize; i++) starfleet.push_back(new Daedalus);
}
void update(void)
{
	fltPulseRotation += 8.0f;

	if (intVibration == 1)
	{
		fltShipY += 0.0025f;
		intVibration = 2;
	}
	else if (intVibration == 2)
	{
		fltShipY -= 0.0025f;
		intVibration = 1;
	}
	glutPostRedisplay();
}
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//build and display textured scene objects
	glUseProgram(textureShader);
	buildBackground();
	buildPlanet();
	buildAsteroid();

	//render hierarchical model of a pulsar
	pulsar->render(fltPulsarX, fltPulsarY, 0.5f, fltPulseRotation);

	//render hierarchical model of USS Daedalus
	float fltYAdjust = 0.0f;
	float fltScaleAdjust = 0.0f;
	for (int i = 0; i < intFleetSize; i++)
	{
		starfleet[i]->render(fltShipX, fltShipY + fltYAdjust, 1.0f - fltScaleAdjust, fltShipPitch);
		fltYAdjust += 0.55f; 
		fltScaleAdjust += 0.33f;
	}
	glutSwapBuffers();
}
#pragma region Event handling functions
void mouseButtonDown(int button_id, int state, int x, int y)
{
	if (button_id == GLUT_LEFT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			intMouseX = x;
			intMouseY = y;
			boolMouseDown = true;

		}
		else if (state == GLUT_UP)
		{

			boolMouseDown = false;
		}
	}
}
void mouseMove(int x, int y)
{
	if (boolMouseDown)
	{
		int dx = x - intMouseX;
		int dy = y - intMouseY;

		if (glutGetModifiers() == GLUT_ACTIVE_CTRL)
		{
			fltAsteroidRotation += float(dy);
		}
		else
		{
			//move asteroid with mouse position
			fltAsteroidX += float(dx) * 0.01f;
			fltAsteroidY -= float(dy) * 0.015f;
		}
		intMouseX = x;
		intMouseY = y;
		glutPostRedisplay();
	}
}
void keyDown(unsigned char key, int x, int y)
{
	if (key == 'r' || key == 'R') //resets the ship's position
	{
		fltShipX = 0.0f;
		fltShipY = 0.0f;
		fltShipPitch = 0.0f;
		glutPostRedisplay();
	}
	
	else if (key == 'a' || key == 'A') //bank ship foward
	{
		fltShipX -= fltSTEP;
		if (fltShipX < -1.25f) fltShipX += 3.0f;
		glutPostRedisplay();
	}
	else if (key == 'd' || key == 'D') //bank ship backwards
	{
		fltShipX += fltSTEP;
		if (fltShipX > 1.74f) fltShipX -= 3.0f;
		glutPostRedisplay();
	}
}
#pragma endregion