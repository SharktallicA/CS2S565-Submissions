#pragma once
#include "Object.h"

class Background : protected Object
{
public:
	Background();
	~Background();
};

