#pragma once

#include <glew\glew.h>
#include <freeglut\freeglut.h>
#include <CoreStructures\CoreStructures.h>
#include <vector>
#include "texture_loader.h"
#include "shader_setup.h"
#include "Circle.h"

class Pulsar
{
private:
	//pulsar components
	Circle* ball1;
	Circle* ball2;

	GLuint pulsarShaderBlue, pulsarShaderRed; //shader programs for pulsar
	GLuint locB; //uniform variable locations in puslarShaders

public:
	Pulsar();
	~Pulsar() { delete ball1; delete ball2; }

	void render(float fltX, float fltY, float fltScale, float fltOrientation);
};