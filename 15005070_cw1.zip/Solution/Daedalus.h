#pragma once

#include <glew\glew.h>
#include <freeglut\freeglut.h>
#include <CoreStructures\CoreStructures.h>
#include <vector>
#include "texture_loader.h"
#include "shader_setup.h"
#include "Circle.h"
#include "Square.h"

class Daedalus
{
	//purpose: hierarchical ship model

private:
	//ship components
	Square* hull;
	Square* neck;
	Circle* saucer;
	Circle* bussard;
	Square* nacelle;
	Square* pylon;

	GLuint shipShader; //shader program for shio
	GLuint locT; //uniform variable locations in shipShader

public:
	Daedalus();
	~Daedalus() { delete hull; delete neck; delete saucer; delete bussard; delete nacelle; delete pylon; }

	void render(float fltX, float fltY, float fltScale, float fltOrientation);
};